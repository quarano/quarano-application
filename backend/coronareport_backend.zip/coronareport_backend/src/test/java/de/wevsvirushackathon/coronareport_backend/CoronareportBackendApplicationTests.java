package de.wevsvirushackathon.coronareport_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoronareportBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
